from django.shortcuts import render 
from django.contrib import messages

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score,classification_report
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from xgboost import XGBClassifier  
from sklearn.ensemble import StackingClassifier
from mlxtend.classifier import StackingCVClassifier
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.pipeline import make_pipeline
# Create your views here.
def index(request):

    return render(request,'home.html')

def about(request):

    return render(request,'about.html')

def viewdata(request):
    dataset = pd.read_csv('app\PCOS_data.csv')
    dataset.drop(['Unnamed: 44'],axis=1,inplace=True)
    dataset.drop(["Sl. No","Patient File No.","II    beta-HCG(mIU/mL)","AMH(ng/mL)"],axis = 1,inplace = True)
    dataset["Marraige Status (Yrs)"].fillna(dataset['Marraige Status (Yrs)'].describe().loc[['50%']][0], inplace = True)
    dataset["Fast food (Y/N)"].fillna(1, inplace = True)
    dataset = dataset[:1000]
   
    return render(request,'viewdata.html',{'columns':dataset.columns.values, 'rows':dataset.values.tolist()})

def model(request):
    global x_train, y_train, x_teat,y_teat
    dataset = pd.read_csv('app\PCOS_data.csv')
    dataset.drop(['Unnamed: 44'],axis=1,inplace=True)
    dataset.drop(["Sl. No","Patient File No.","II    beta-HCG(mIU/mL)","AMH(ng/mL)"],axis = 1,inplace = True)
    dataset["Marraige Status (Yrs)"].fillna(dataset['Marraige Status (Yrs)'].describe().loc[['50%']][0], inplace = True)
    dataset["Fast food (Y/N)"].fillna(1, inplace = True)
    dataset.rename(columns = {'PCOS (Y/N)':'PCOS'}, inplace = True)
    x = dataset.drop(['PCOS'],axis=1)
    y = dataset['PCOS']       
    x_train,x_test,y_train,y_test = train_test_split(x, y,test_size=0.3,random_state=72)
    if request.method == "POST":

        model = request.POST['algo']

        if model == "0":
            dt = RandomForestClassifier()
            dt.fit(x_train,y_train)
            dtp = dt.predict(x_test)
            dta =  accuracy_score(y_test,dtp)*100
            msg = 'Accuracy of RandomForest Classifier : ' + str(dta)
            return render(request,'model.html',{'msg':msg})
        elif model == "1":
            lr = DecisionTreeClassifier()
            lr.fit(x_train,y_train)
            lrp = lr.predict(x_test)
            lra = accuracy_score(y_test,lrp)*100
            msg = 'Accuracy oo Decesion Tree Clasifiers :  ' + str(lra)
           
            return render(request,'model.html',{'msg':msg})
        elif model == "2":
            cb = XGBClassifier()
            cb.fit(x_train,y_train)
            cbp = cb.predict(x_test)
            cba = accuracy_score(y_test,cbp)*100
            
            msg = 'Accuracy of XGBClassifier :  ' + str(cba)

           
            return render(request,'model.html',{'msg':msg})

        elif model == "3":
            ad = AdaBoostClassifier()
            ad.fit(x_train,y_train)
            adp = ad.predict(x_test)
            ada = accuracy_score(y_test,adp)*100
            
            msg = 'Accuracy of AdaBoostClassifier :  ' + str(ada)
            
           
            return render(request,'model.html',{'msg':msg})

        elif model == "4":

            estimators = [
                        ('rf', RandomForestClassifier(n_estimators=10, random_state=42)),
                        ('ab', make_pipeline(XGBClassifier(random_state=42)))]
            clf = StackingClassifier(
            estimators=estimators, final_estimator=AdaBoostClassifier())
            # model1 = RandomForestClassifier()
            # model2 = XGBClassifier()

            # lr = AdaBoostClassifier()
            # clf_stack = StackingClassifier(classifiers=[model1, model2], meta_classifier=lr, use_probas=True,
            #                                             use_features_in_secondary=True)
            model_stack = clf.fit(x_train, y_train)
            pred_stack = model_stack.predict(x_test)
            acc_stack = accuracy_score(y_test, pred_stack)
      
            msg = 'Accuracy of StackingClassifier :  ' + str(acc_stack)
            
           
            return render(request,'model.html',{'msg':msg})
        

    return render(request,'model.html')

def prediction(request):
    dataset = pd.read_csv('app\PCOS_data.csv')
    dataset.drop(['Unnamed: 44'],axis=1,inplace=True)
    dataset.drop(["Sl. No","Patient File No.","II    beta-HCG(mIU/mL)","AMH(ng/mL)"],axis = 1,inplace = True)
    dataset["Marraige Status (Yrs)"].fillna(dataset['Marraige Status (Yrs)'].describe().loc[['50%']][0], inplace = True)
    dataset["Fast food (Y/N)"].fillna(1, inplace = True)
    dataset.rename(columns = {'PCOS (Y/N)':'PCOS'}, inplace = True)
    x = dataset.drop(['PCOS'],axis=1)
    y = dataset['PCOS']       
    x_train,x_test,y_train,y_test = train_test_split(x, y,test_size=0.3,random_state=72)
    if request.method == 'POST':

        a = request.POST['f1']
        b = request.POST['f2']
        c = request.POST['f3']
        d = request.POST['f4']
        e = request.POST['f5']
        f = request.POST['f6']
        g = request.POST['f7']
        h = request.POST['f8']
        i = request.POST['f9']
        j = request.POST['f10']
        k = request.POST['f11']
        l = request.POST['f12']
        m = request.POST['f13']
        n = request.POST['f14']
        o = request.POST['f15']
        p = request.POST['f16']
        q = request.POST['f17']
        r = request.POST['f18']
        s = request.POST['f19']
        t = request.POST['f20']
        u = request.POST['f21']
        v = request.POST['f22']
        w = request.POST['f23']
        x = request.POST['f24']
        y = request.POST['f25']
        z = request.POST['f26']
        aa = request.POST['f27']
        bb = request.POST['f28']
        cc = request.POST['f29']
        dd = request.POST['f30']
        ee = request.POST['f31']
        ff = request.POST['f32']
        gg = request.POST['f33']
        hh = request.POST['f34']
        ii = request.POST['f35']
        jj = request.POST['f36']
        kk = request.POST['f37']
        ll = request.POST['f38']
        mm = request.POST['f39']
        

        l = [[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk,ll,mm]]

        rf = RandomForestClassifier()
        rf.fit(x_train,y_train)
        xgp = rf.predict(l)

        if xgp==0:
           
            msg = ' <span style = color:black;>This prediction result is : <span style = color:green;><b>No Polycystic Ovarian Syndrome </b></span></span>'
        elif xgp==1:
            msg = ' <span style = color:black;>This prediction result is : <span style = color:red;><b>Polycystic Ovarian Syndrome </b></span></span>'
        
        return render(request,'prediction.html',{'msg':msg})

    return render(request,'prediction.html')
