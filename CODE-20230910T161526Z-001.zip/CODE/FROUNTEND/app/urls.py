from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns=[
    path("",views.index,name='home'),
    path("/about",views.about,name='about'),
    path("/viewdata",views.viewdata,name='viewdata'),
    path("/model",views.model,name='model'),
    path("/prediction",views.prediction,name='prediction'),
    
]